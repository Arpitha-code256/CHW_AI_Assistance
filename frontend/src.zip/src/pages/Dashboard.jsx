import React from "react";

function Dashboard() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-6">
        <h1 className="text-2xl sm:text-3xl font-bold text-slate-900">
          Community Health Worker Dashboard
        </h1>
        <p className="text-sm text-slate-600 mt-1">
          Welcome to the Community Health Worker Assistance Platform.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-6">
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
          <h2 className="text-3xl font-extrabold text-slate-900">0</h2>
          <p className="text-xs font-semibold text-slate-500 uppercase mt-1">Community Members</p>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
          <h2 className="text-3xl font-extrabold text-emerald-600">0</h2>
          <p className="text-xs font-semibold text-slate-500 uppercase mt-1">Today's Visits</p>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
          <h2 className="text-3xl font-extrabold text-teal-600">0</h2>
          <p className="text-xs font-semibold text-slate-500 uppercase mt-1">Appointments</p>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
          <h2 className="text-3xl font-extrabold text-amber-600">0</h2>
          <p className="text-xs font-semibold text-slate-500 uppercase mt-1">Follow-ups</p>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;