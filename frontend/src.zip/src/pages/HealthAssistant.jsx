import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  Bot,
  CheckCircle2,
  ChevronRight,
  ClipboardCheck,
  HeartPulse,
  MessageCircle,
  PhoneCall,
  Send,
  ShieldAlert,
  UserRound,
} from 'lucide-react';

const initialPatient = {
  name: 'Ravi Kumar',
  age: '35',
  symptoms: 'Mild dizziness in the evening',
  bloodPressure: '128/82',
  bloodSugar: '110',
  pregnancy: false,
};

const quickQuestions = [
  'What should I check for dizziness?',
  'Explain the warning signs in this case',
  'What information should I send to the supervisor?',
];

function getRedFlags(patient) {
  const flags = [];
  const systolic = Number(patient.bloodPressure.split('/')[0]);
  const diastolic = Number(patient.bloodPressure.split('/')[1]);
  const glucose = Number(patient.bloodSugar);
  const symptoms = patient.symptoms.toLowerCase();

  if (systolic >= 180 || diastolic >= 120) flags.push('Very high blood pressure');
  if (glucose >= 300 || glucose > 0 && glucose < 70) flags.push('Critical blood sugar reading');
  if (/chest pain|severe breath|difficulty breathing|unconscious|fainting|severe bleeding|seizure/.test(symptoms)) {
    flags.push('Potential emergency symptom');
  }
  if (patient.pregnancy && /bleeding|severe headache|blurred vision|convulsion|severe pain/.test(symptoms)) {
    flags.push('High-risk pregnancy symptom');
  }

  return flags;
}

function buildAdvice(patient, flags) {
  if (flags.length > 0) {
    return `Potential warning signs detected: ${flags.join(', ')}. Keep the patient supervised, repeat the measurement if safe, and contact a qualified supervisor or clinician now. Do not delay emergency referral for this chat.`;
  }

  if (/dizz|weak|tired/.test(patient.symptoms.toLowerCase())) {
    return 'For mild dizziness, check hydration, recent food intake, temperature, blood pressure, blood sugar, medication history, and whether the patient has fainted or developed new weakness. Escalate if symptoms worsen or new red flags appear.';
  }

  return 'No rule-based red flags were detected from the entered information. Record the context, monitor the patient, follow your local care protocol, and consult a supervisor when the situation is uncertain.';
}

export default function HealthAssistant() {
  const [patient, setPatient] = useState(initialPatient);
  const [messages, setMessages] = useState([
    {
      from: 'assistant',
      text: 'I can help organize health information, identify possible warning signs, and prepare a supervisor handoff. I do not replace a clinician or emergency services.',
    },
  ]);
  const [question, setQuestion] = useState('');
  const [escalated, setEscalated] = useState(false);
  const redFlags = useMemo(() => getRedFlags(patient), [patient]);
  const advice = useMemo(() => buildAdvice(patient, redFlags), [patient, redFlags]);

  const updatePatient = (event) => {
    const { name, value, type, checked } = event.target;
    setPatient((current) => ({ ...current, [name]: type === 'checkbox' ? checked : value }));
  };

  const analyzeCase = () => {
    setMessages((current) => [...current, { from: 'assistant', text: advice }]);
  };

  const askQuestion = (event) => {
    event.preventDefault();
    const trimmedQuestion = question.trim();
    if (!trimmedQuestion) return;

    const lowerQuestion = trimmedQuestion.toLowerCase();
    let response = advice;
    if (lowerQuestion.includes('supervisor') || lowerQuestion.includes('send')) {
      response = `Supervisor handoff: ${patient.name || 'Unnamed patient'}, age ${patient.age || 'unknown'}, symptoms: ${patient.symptoms || 'not entered'}, BP ${patient.bloodPressure || 'not entered'}, glucose ${patient.bloodSugar || 'not entered'}. Include onset, duration, medications, and actions already taken.`;
    } else if (lowerQuestion.includes('warning') || lowerQuestion.includes('red flag')) {
      response = redFlags.length ? `Possible red flags: ${redFlags.join(', ')}. Escalate now.` : 'No rule-based red flags detected from the current fields. Continue observation and follow local protocol.';
    } else if (lowerQuestion.includes('dizz')) {
      response = 'Check hydration, food intake, temperature, blood pressure, blood sugar, medication changes, fainting, new weakness, speech changes, severe headache, and chest or breathing symptoms.';
    }

    setMessages((current) => [
      ...current,
      { from: 'worker', text: trimmedQuestion },
      { from: 'assistant', text: response },
    ]);
    setQuestion('');
  };

  const escalate = () => {
    setEscalated(true);
    setMessages((current) => [
      ...current,
      { from: 'assistant', text: 'Escalation marked. Contact the assigned supervisor or clinician using your approved local channel and share the structured handoff below.' },
    ]);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl font-bold text-slate-900">Health Assistant</h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-cyan-50 text-cyan-700 border border-cyan-200">Decision support</span>
          </div>
          <p className="text-sm text-slate-600 mt-1">Organize patient information, review possible warning signs, and prepare a safe supervisor handoff.</p>
        </div>
        <div className="flex items-center gap-2 text-xs text-slate-500">
          <ShieldAlert className="w-4 h-4 text-amber-500" />
          Not a diagnosis or emergency service
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-[minmax(0,0.8fr)_minmax(0,1.2fr)] gap-6 items-start">
        <section className="bg-white rounded-2xl border border-slate-200 shadow-xs p-5 space-y-5">
          <div className="flex items-center gap-2">
            <ClipboardCheck className="w-5 h-5 text-emerald-600" />
            <div>
              <h2 className="font-bold text-slate-900">Patient information</h2>
              <p className="text-xs text-slate-500">Enter only information you are authorized to use.</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <label className="text-xs font-semibold text-slate-700">Patient name
              <input name="name" value={patient.name} onChange={updatePatient} className="mt-1 w-full px-3 py-2 border border-slate-300 rounded-xl font-normal text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500" />
            </label>
            <label className="text-xs font-semibold text-slate-700">Age
              <input name="age" type="number" value={patient.age} onChange={updatePatient} className="mt-1 w-full px-3 py-2 border border-slate-300 rounded-xl font-normal text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500" />
            </label>
          </div>
          <label className="block text-xs font-semibold text-slate-700">Symptoms or observations
            <textarea name="symptoms" value={patient.symptoms} onChange={updatePatient} rows="3" className="mt-1 w-full px-3 py-2 border border-slate-300 rounded-xl font-normal text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500" />
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <label className="text-xs font-semibold text-slate-700">Blood pressure
              <input name="bloodPressure" value={patient.bloodPressure} onChange={updatePatient} placeholder="e.g. 128/82" className="mt-1 w-full px-3 py-2 border border-slate-300 rounded-xl font-normal text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500" />
            </label>
            <label className="text-xs font-semibold text-slate-700">Blood sugar mg/dL
              <input name="bloodSugar" type="number" value={patient.bloodSugar} onChange={updatePatient} className="mt-1 w-full px-3 py-2 border border-slate-300 rounded-xl font-normal text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500" />
            </label>
          </div>
          <label className="flex items-center gap-2 text-xs font-semibold text-slate-700">
            <input name="pregnancy" type="checkbox" checked={patient.pregnancy} onChange={updatePatient} className="rounded border-slate-300 text-emerald-600 focus:ring-emerald-500" />
            Patient is pregnant or recently postpartum
          </label>

          <div className={`rounded-xl border p-4 ${redFlags.length ? 'bg-rose-50 border-rose-200' : 'bg-emerald-50 border-emerald-200'}`}>
            <div className="flex items-center gap-2">
              {redFlags.length ? <AlertTriangle className="w-5 h-5 text-rose-600" /> : <CheckCircle2 className="w-5 h-5 text-emerald-600" />}
              <h3 className={`font-bold text-sm ${redFlags.length ? 'text-rose-800' : 'text-emerald-800'}`}>{redFlags.length ? 'Potential red flags' : 'No rule-based red flags detected'}</h3>
            </div>
            {redFlags.length > 0 && <ul className="mt-2 list-disc list-inside text-xs text-rose-700 space-y-1">{redFlags.map((flag) => <li key={flag}>{flag}</li>)}</ul>}
            <p className="mt-2 text-xs text-slate-600">{advice}</p>
          </div>

          <div className="flex flex-wrap gap-2">
            <button type="button" onClick={analyzeCase} className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700"><HeartPulse className="w-4 h-4" /> Review case</button>
            <button type="button" onClick={escalate} className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-200"><PhoneCall className="w-4 h-4" /> {escalated ? 'Escalation marked' : 'Escalate case'}</button>
          </div>
        </section>

        <section className="bg-slate-900 rounded-2xl shadow-xs overflow-hidden flex flex-col min-h-[620px]">
          <div className="p-5 border-b border-slate-700 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-cyan-400/15 text-cyan-300 flex items-center justify-center"><Bot className="w-5 h-5" /></div>
              <div><h2 className="font-bold text-white">CHW Support Chat</h2><p className="text-xs text-slate-400">Health information and escalation guidance</p></div>
            </div>
            <span className="inline-flex items-center gap-1.5 text-[11px] text-emerald-300"><span className="w-2 h-2 rounded-full bg-emerald-400" />Ready</span>
          </div>
          <div className="flex-1 p-5 space-y-4 overflow-y-auto">
            {messages.map((message, index) => (
              <div key={`${message.from}-${index}`} className={`flex gap-2 ${message.from === 'worker' ? 'justify-end' : ''}`}>
                {message.from !== 'worker' && <Bot className="w-4 h-4 text-cyan-300 mt-1 shrink-0" />}
                <div className={`max-w-[85%] rounded-2xl px-4 py-3 text-xs leading-relaxed ${message.from === 'worker' ? 'bg-emerald-600 text-white rounded-br-sm' : 'bg-slate-800 text-slate-200 rounded-bl-sm'}`}>{message.text}</div>
                {message.from === 'worker' && <UserRound className="w-4 h-4 text-emerald-300 mt-1 shrink-0" />}
              </div>
            ))}
            <div className="pt-2 flex flex-wrap gap-2">
              {quickQuestions.map((prompt) => <button key={prompt} type="button" onClick={() => setQuestion(prompt)} className="inline-flex items-center gap-1 text-left px-3 py-2 rounded-lg bg-slate-800 text-slate-300 hover:bg-slate-700 text-[11px]">{prompt}<ChevronRight className="w-3 h-3" /></button>)}
            </div>
          </div>
          <form onSubmit={askQuestion} className="p-4 border-t border-slate-700 flex gap-2">
            <MessageCircle className="w-4 h-4 text-slate-500 mt-2.5 shrink-0" />
            <input value={question} onChange={(event) => setQuestion(event.target.value)} placeholder="Ask about the entered case..." className="flex-1 min-w-0 bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-cyan-400" />
            <button type="submit" title="Send question" className="p-2.5 rounded-xl bg-cyan-500 text-slate-950 hover:bg-cyan-400"><Send className="w-4 h-4" /></button>
          </form>
        </section>
      </div>
    </div>
  );
}
