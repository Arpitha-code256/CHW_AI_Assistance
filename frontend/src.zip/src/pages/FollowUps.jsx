import React, { useState } from 'react';
import { AlertTriangle, CheckCircle2, Clock, Plus } from 'lucide-react';

export default function FollowUps() {
  const [followups] = useState([
    {
      id: 1,
      memberName: 'Kamla Devi',
      reason: 'Check postpartum recovery & neonatal temperature',
      dueDate: '2025-02-28',
      worker: 'Anita Devi (CHW)',
      status: 'Pending',
    },
    {
      id: 2,
      memberName: 'Sanjay Rawat',
      reason: 'Verify adherence to TB medication regimen',
      dueDate: '2025-02-20',
      worker: 'Anita Devi (CHW)',
      status: 'Overdue',
    },
    {
      id: 3,
      memberName: 'Ravi Kumar',
      reason: 'Follow-up blood pressure measurement after diet change',
      dueDate: '2025-02-15',
      worker: 'Anita Devi (CHW)',
      status: 'Completed',
    },
  ]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900">Patient Follow-ups</h1>
          <p className="text-sm text-slate-600 mt-1">
            Track pending, completed, and overdue health surveillance tasks for vulnerable patients.
          </p>
        </div>

        <button className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 transition-colors shadow-xs">
          <Plus className="w-4 h-4" />
          <span>New Follow-up</span>
        </button>
      </div>

      {/* Summary Chips */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-xs text-slate-500 font-medium">Pending Tasks</p>
            <p className="text-2xl font-bold text-slate-900">1</p>
          </div>
          <Clock className="w-6 h-6 text-amber-500" />
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-xs text-slate-500 font-medium">Overdue Reminders</p>
            <p className="text-2xl font-bold text-rose-600">1</p>
          </div>
          <AlertTriangle className="w-6 h-6 text-rose-500" />
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-xs text-slate-500 font-medium">Completed</p>
            <p className="text-2xl font-bold text-emerald-600">1</p>
          </div>
          <CheckCircle2 className="w-6 h-6 text-emerald-500" />
        </div>
      </div>

      {/* Follow-up List */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="divide-y divide-slate-100">
          {followups.map((item) => (
            <div key={item.id} className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-slate-50/60 transition-colors">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-slate-900 text-sm">{item.memberName}</span>
                  <span
                    className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold border ${
                      item.status === 'Completed'
                        ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                        : item.status === 'Overdue'
                        ? 'bg-rose-50 text-rose-700 border-rose-200'
                        : 'bg-amber-50 text-amber-700 border-amber-200'
                    }`}
                  >
                    {item.status === 'Completed' && <CheckCircle2 className="w-3 h-3" />}
                    {item.status === 'Overdue' && <AlertTriangle className="w-3 h-3" />}
                    {item.status === 'Pending' && <Clock className="w-3 h-3" />}
                    {item.status}
                  </span>
                </div>
                <p className="text-xs text-slate-600">{item.reason}</p>
                <p className="text-[11px] text-slate-400">
                  Due by <span className="font-medium text-slate-700">{item.dueDate}</span> • Assigned to {item.worker}
                </p>
              </div>

              <div className="flex items-center gap-2">
                {item.status !== 'Completed' && (
                  <button className="px-3 py-1.5 rounded-lg text-xs font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 transition-colors">
                    Mark Completed
                  </button>
                )}
                <button className="px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-600 hover:text-slate-900 transition-colors">
                  Details
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
