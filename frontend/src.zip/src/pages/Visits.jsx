import React, { useState } from 'react';
import { Clock, Plus, CheckCircle2, XCircle } from 'lucide-react';

export default function Visits() {
  const [filter, setFilter] = useState('All');
  const [visits] = useState([
    {
      id: 1,
      memberName: 'Sita Devi',
      date: '2025-02-25',
      time: '10:30 AM',
      visitType: 'Maternal ANC Checkup',
      worker: 'Anita Devi',
      status: 'Scheduled',
    },
    {
      id: 2,
      memberName: 'Ravi Kumar',
      date: '2025-02-20',
      time: '02:00 PM',
      visitType: 'Hypertension Monitoring',
      worker: 'Anita Devi',
      status: 'Completed',
    },
    {
      id: 3,
      memberName: 'Anil Verma',
      date: '2025-02-18',
      time: '11:00 AM',
      visitType: 'Routine Nutrition Survey',
      worker: 'Kavita Singh',
      status: 'Cancelled',
    },
  ]);

  const filteredVisits = filter === 'All' ? visits : visits.filter((v) => v.status === filter);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900">Home & Sector Visits</h1>
          <p className="text-sm text-slate-600 mt-1">
            Schedule, manage, and record household visits conducted by frontline workers.
          </p>
        </div>

        <button className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 transition-colors shadow-xs">
          <Plus className="w-4 h-4" />
          <span>Schedule Visit</span>
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-3">
        {['All', 'Scheduled', 'Completed', 'Cancelled'].map((tab) => (
          <button
            key={tab}
            onClick={() => setFilter(tab)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              filter === tab
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Visits Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs sm:text-sm">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
              <tr>
                <th className="p-3.5">Community Member</th>
                <th className="p-3.5">Date & Time</th>
                <th className="p-3.5">Visit Type</th>
                <th className="p-3.5">Assigned Worker</th>
                <th className="p-3.5">Status</th>
                <th className="p-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredVisits.length === 0 ? (
                <tr>
                  <td colSpan="6" className="p-8 text-center text-slate-500">
                    No visits recorded for status "{filter}".
                  </td>
                </tr>
              ) : (
                filteredVisits.map((visit) => (
                  <tr key={visit.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="p-3.5 font-semibold text-slate-900">{visit.memberName}</td>
                    <td className="p-3.5 text-slate-500">
                      {visit.date} at {visit.time}
                    </td>
                    <td className="p-3.5">{visit.visitType}</td>
                    <td className="p-3.5 text-slate-600">{visit.worker}</td>
                    <td className="p-3.5">
                      <span
                        className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold border ${
                          visit.status === 'Completed'
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                            : visit.status === 'Cancelled'
                            ? 'bg-rose-50 text-rose-700 border-rose-200'
                            : 'bg-amber-50 text-amber-700 border-amber-200'
                        }`}
                      >
                        {visit.status === 'Completed' && <CheckCircle2 className="w-3 h-3" />}
                        {visit.status === 'Cancelled' && <XCircle className="w-3 h-3" />}
                        {visit.status === 'Scheduled' && <Clock className="w-3 h-3" />}
                        {visit.status}
                      </span>
                    </td>
                    <td className="p-3.5 text-right">
                      <button className="text-xs font-semibold text-emerald-600 hover:text-emerald-800">
                        View Details
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
