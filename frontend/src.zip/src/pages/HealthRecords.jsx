import React, { useState } from 'react';
import { Plus, Search } from 'lucide-react';

export default function HealthRecords() {
  const [records] = useState([
    {
      id: 1,
      memberName: 'Ravi Kumar',
      date: '2025-02-10',
      bp: '128/82 mmHg',
      sugar: '110 mg/dL',
      weight: '68 kg',
      symptoms: 'Mild dizziness in evening',
      medication: 'Amlodipine 5mg',
      worker: 'Anita Devi (CHW)',
    },
    {
      id: 2,
      memberName: 'Pooja Sharma',
      date: '2025-02-14',
      bp: '118/76 mmHg',
      sugar: '94 mg/dL',
      weight: '54 kg',
      symptoms: 'ANC 2 routine checkup',
      medication: 'Iron & Folic Acid tablets',
      worker: 'Anita Devi (CHW)',
    },
  ]);

  const [search, setSearch] = useState('');

  const filtered = records.filter(
    (r) =>
      r.memberName.toLowerCase().includes(search.toLowerCase()) ||
      r.symptoms.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl font-bold text-slate-900">Health Records</h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800">
              Vitals & Care Logs
            </span>
          </div>
          <p className="text-sm text-slate-600 mt-1">
            Maintain community member vitals, symptoms, observations, and prescribed medication logs.
          </p>
        </div>

        <button className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 transition-colors shadow-xs">
          <Plus className="w-4 h-4" />
          <span>New Health Record</span>
        </button>
      </div>

      {/* Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-3">
        <Search className="w-4 h-4 text-slate-400" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search by community member name or symptoms..."
          className="w-full text-xs sm:text-sm bg-transparent focus:outline-none text-slate-800 placeholder:text-slate-400"
        />
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs sm:text-sm">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
              <tr>
                <th className="p-3.5">Member Name</th>
                <th className="p-3.5">Record Date</th>
                <th className="p-3.5">Blood Pressure</th>
                <th className="p-3.5">Blood Sugar</th>
                <th className="p-3.5">Symptoms / Notes</th>
                <th className="p-3.5">Medication</th>
                <th className="p-3.5">Logged By</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan="7" className="p-8 text-center text-slate-500">
                    No health records match your criteria.
                  </td>
                </tr>
              ) : (
                filtered.map((record) => (
                  <tr key={record.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="p-3.5 font-semibold text-slate-900">{record.memberName}</td>
                    <td className="p-3.5 text-slate-500">{record.date}</td>
                    <td className="p-3.5 font-medium text-emerald-700">{record.bp}</td>
                    <td className="p-3.5">{record.sugar}</td>
                    <td className="p-3.5 max-w-xs truncate">{record.symptoms}</td>
                    <td className="p-3.5 text-teal-700">{record.medication}</td>
                    <td className="p-3.5 text-slate-500 text-xs">{record.worker}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
