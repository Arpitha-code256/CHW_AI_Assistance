import React, { useState } from 'react';
import { Search } from 'lucide-react';

export default function HealthEducation() {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [search, setSearch] = useState('');

  const articles = [
    {
      id: 1,
      title: 'Essential Nutritional Guidelines for First-Trimester Mothers',
      category: 'Maternal Health',
      summary: 'Guidance on iron, folic acid, dietary sources, and identification of severe morning sickness symptoms.',
      readTime: '4 min read',
    },
    {
      id: 2,
      title: 'Routine Immunization Schedule from Birth to 12 Months',
      category: 'Child Health',
      summary: 'Recommended vaccination calendar including BCG, Pentavalent, Rotavirus, and MR dose timings.',
      readTime: '6 min read',
    },
    {
      id: 3,
      title: 'Community Screening for Early Hypertension',
      category: 'Hypertension',
      summary: 'Protocol for accurate digital and manual sphygmomanometer readings and referral thresholds for PHCs.',
      readTime: '5 min read',
    },
    {
      id: 4,
      title: 'Water Purification & Rural Sanitation Hygiene Standards',
      category: 'Hygiene',
      summary: 'Practical disinfection techniques for village borewells and preventing monsoon-borne diarrheal outbreaks.',
      readTime: '3 min read',
    },
  ];

  const categories = ['All', 'Maternal Health', 'Child Health', 'Hypertension', 'Hygiene'];

  const filtered = articles.filter((a) => {
    const matchCategory = selectedCategory === 'All' || a.category === selectedCategory;
    const matchSearch =
      a.title.toLowerCase().includes(search.toLowerCase()) ||
      a.summary.toLowerCase().includes(search.toLowerCase());
    return matchCategory && matchSearch;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2">
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900">Health Education & Knowledge Base</h1>
          <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800">
            Field Guidelines
          </span>
        </div>
        <p className="text-sm text-slate-600 mt-1">
          Informational modules and counseling reference guides to assist workers during household visits.
        </p>
      </div>

      {/* Search and Category Filters */}
      <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
        <div className="w-full sm:w-80 bg-white p-3 rounded-xl border border-slate-200 shadow-xs flex items-center gap-2">
          <Search className="w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search educational guides..."
            className="w-full text-xs sm:text-sm bg-transparent focus:outline-none text-slate-800"
          />
        </div>

        <div className="flex flex-wrap items-center gap-1.5 w-full sm:w-auto">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                selectedCategory === cat
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Article Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.map((item) => (
          <div key={item.id} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between space-y-4 hover:border-emerald-300 transition-colors">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                  {item.category}
                </span>
                <span className="text-xs text-slate-400 font-medium">{item.readTime}</span>
              </div>
              <h2 className="text-base font-bold text-slate-900 leading-snug">{item.title}</h2>
              <p className="text-xs text-slate-600 leading-relaxed">{item.summary}</p>
            </div>

            <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
              <span className="text-slate-400">National Health Portal Guidelines</span>
              <button className="font-semibold text-emerald-600 hover:text-emerald-800">
                Read Full Guide &rarr;
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Medical Disclaimer */}
      <div className="p-4 bg-slate-100/70 border border-slate-200 rounded-xl text-xs text-slate-500">
        <p>
          <span className="font-semibold text-slate-700">Notice:</span> Educational materials provided are for informational counseling purposes for community health workers and do not represent automated medical diagnoses.
        </p>
      </div>
    </div>
  );
}
