import React, { useState } from 'react';
import { Download, Users, CheckCircle2, Clock, FileText } from 'lucide-react';

export default function Reports() {
  const [timeRange, setTimeRange] = useState('This Month');

  const stats = [
    { label: 'Total Community Members', value: 48, change: '+12% from last month', icon: Users, color: 'text-blue-600', bg: 'bg-blue-50' },
    { label: 'Completed Field Visits', value: 34, change: '92% adherence rate', icon: CheckCircle2, color: 'text-emerald-600', bg: 'bg-emerald-50' },
    { label: 'Pending Visits', value: 6, change: 'Scheduled this week', icon: Clock, color: 'text-amber-600', bg: 'bg-amber-50' },
    { label: 'Logged Health Records', value: 72, change: 'Vitals & prescriptions', icon: FileText, color: 'text-purple-600', bg: 'bg-purple-50' },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900">Health Reports & Analytics</h1>
          <p className="text-sm text-slate-600 mt-1">
            Aggregated coverage metrics, visit completion rates, and primary care interventions.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <select
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value)}
            className="px-3 py-2 text-xs font-semibold bg-white border border-slate-300 rounded-xl text-slate-700 focus:outline-none"
          >
            <option value="This Week">This Week</option>
            <option value="This Month">This Month</option>
            <option value="All Time">All Time</option>
          </select>

          <button className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 transition-colors">
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((item, idx) => {
          const Icon = item.icon;
          return (
            <div key={idx} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                  {item.label}
                </span>
                <div className={`w-8 h-8 rounded-xl ${item.bg} ${item.color} flex items-center justify-center`}>
                  <Icon className="w-4 h-4" />
                </div>
              </div>
              <p className="text-3xl font-extrabold text-slate-900">{item.value}</p>
              <p className="text-xs text-slate-500 font-medium">{item.change}</p>
            </div>
          );
        })}
      </div>

      {/* Breakdown Card */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <h2 className="text-base font-bold text-slate-900">MCH & Immunization Program Summary</h2>
        <div className="space-y-3 text-xs sm:text-sm">
          <div>
            <div className="flex justify-between mb-1">
              <span className="font-semibold text-slate-700">Maternal Health Registrations (ANC 1-4)</span>
              <span className="font-bold text-slate-900">88%</span>
            </div>
            <div className="w-full bg-slate-100 rounded-full h-2">
              <div className="bg-emerald-500 h-2 rounded-full" style={{ width: '88%' }} />
            </div>
          </div>

          <div>
            <div className="flex justify-between mb-1">
              <span className="font-semibold text-slate-700">Infant Immunization Coverage</span>
              <span className="font-bold text-slate-900">94%</span>
            </div>
            <div className="w-full bg-slate-100 rounded-full h-2">
              <div className="bg-teal-500 h-2 rounded-full" style={{ width: '94%' }} />
            </div>
          </div>

          <div>
            <div className="flex justify-between mb-1">
              <span className="font-semibold text-slate-700">Non-Communicable Disease (NCD) Follow-up Rate</span>
              <span className="font-bold text-slate-900">76%</span>
            </div>
            <div className="w-full bg-slate-100 rounded-full h-2">
              <div className="bg-amber-500 h-2 rounded-full" style={{ width: '76%' }} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
