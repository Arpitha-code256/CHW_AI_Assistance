import React, { useState } from 'react';
import { Calendar, Plus, MapPin, User, CheckCircle2, Clock } from 'lucide-react';

export default function Appointments() {
  const [appointments] = useState([
    {
      id: 1,
      memberName: 'Meera Bai',
      date: '2025-03-01',
      time: '09:30 AM',
      provider: 'Dr. R. Sharma (Medical Officer)',
      location: 'Primary Health Centre - Sector 4',
      purpose: 'High-risk Antenatal Ultrasound Review',
      status: 'Upcoming',
    },
    {
      id: 2,
      memberName: 'Ravi Kumar',
      date: '2025-02-12',
      time: '11:00 AM',
      provider: 'Dr. Preeti Das (General Physician)',
      location: 'Sub-Centre Clinic Room 2',
      purpose: 'Cardiovascular Risk Evaluation',
      status: 'Completed',
    },
  ]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900">Clinical Appointments</h1>
          <p className="text-sm text-slate-600 mt-1">
            Track and coordinate appointments between community members and PHC doctors.
          </p>
        </div>

        <button className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 transition-colors shadow-xs">
          <Plus className="w-4 h-4" />
          <span>New Appointment</span>
        </button>
      </div>

      {/* Appointment Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {appointments.map((apt) => (
          <div key={apt.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <span
                className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold border ${
                  apt.status === 'Completed'
                    ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                    : 'bg-teal-50 text-teal-700 border-teal-200'
                }`}
              >
                {apt.status === 'Completed' ? <CheckCircle2 className="w-3 h-3" /> : <Clock className="w-3 h-3" />}
                {apt.status}
              </span>
              <span className="text-xs text-slate-400 font-mono">APT-00{apt.id}</span>
            </div>

            <div>
              <h3 className="text-base font-bold text-slate-900">{apt.memberName}</h3>
              <p className="text-xs text-slate-600 mt-0.5">{apt.purpose}</p>
            </div>

            <div className="pt-2 border-t border-slate-100 text-xs text-slate-600 space-y-1.5">
              <div className="flex items-center gap-2">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                <span>{apt.date} • {apt.time}</span>
              </div>
              <div className="flex items-center gap-2">
                <User className="w-3.5 h-3.5 text-slate-400" />
                <span>{apt.provider}</span>
              </div>
              <div className="flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-slate-400" />
                <span>{apt.location}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
